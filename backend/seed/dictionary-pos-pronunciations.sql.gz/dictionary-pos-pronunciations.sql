-- Phát âm riêng theo loại từ (dictionary_words.pos_pronunciations) cho từ đồng tự khác âm phổ biến.
-- Nguồn IPA: Wiktionary qua dump kaikki.org, lấy nguyên chuỗi từ dictionary_words.final.jsonl của FluentDict.
-- Không nạp tự động cả 965 từ có ghi đè trong FluentDict: script gốc so với mục Wiktionary đầu tiên (thường là từ cổ,
-- tên riêng, từ ngoại lai) nên sinh nhiều ghi đè sai (seat /ˈseɪæt/, flower /ˈfləʊə/, read /ɹɛd/...).
-- Danh sách này chọn tay các từ đồng tự khác âm kinh điển; chuỗi IPA nào gán cho loại từ nào được chọn tay khi Wiktionary
-- gán nhầm (vd refuse danh từ dùng IPA mặc định /ˈɹɛfjuːs/). Bỏ ipa_us khi giá trị US của Wiktionary sai
-- (object, contest, progress động từ). Chỉ ghi loại từ khác cách đọc mặc định của từ trong seed LinguaLoop; từ có IPA mặc
-- định UK và US lệch loại từ thì ghi cả hai loại từ. audio_* để NULL: chưa có âm thanh theo loại từ.
-- Cần đã nạp dictionary-words.sql.gz. Chạy lại an toàn: chỉ UPDATE.
BEGIN;
CREATE TEMP TABLE pos_pron (headword text PRIMARY KEY, data jsonb NOT NULL) ON COMMIT DROP;
INSERT INTO pos_pron (headword, data) VALUES
('present', '{"verb": {"ipa_uk": "/pɹɪˈzɛnt/", "ipa_us": "/pɹɪˈzɛnt/"}}'),
('record', '{"verb": {"ipa_uk": "/ɹɪˈkɔːd/", "ipa_us": "/ɹɪˈkɔɹd/"}}'),
('object', '{"verb": {"ipa_uk": "/əbˈd͡ʒɛkt/", "ipa_us": null}}'),
('project', '{"noun": {"ipa_uk": "/ˈpɹɒd͡ʒ.ɛkt/", "ipa_us": "/ˈpɹɑˌd͡ʒɛkt/"}}'),
('permit', '{"noun": {"ipa_uk": "/ˈpɜːmɪt/", "ipa_us": "/ˈpɝmɪt/"}}'),
('produce', '{"noun": {"ipa_uk": "/ˈpɹɒd͡ʒuːs/", "ipa_us": "/ˈpɹoʊ.dus/"}}'),
('refuse', '{"verb": {"ipa_uk": "/ɹɪˈfjuːz/", "ipa_us": "/ɹɪˈfjuz/"}, "noun": {"ipa_uk": "/ˈɹɛfjuːs/", "ipa_us": "/ˈɹɛfjuːs/"}}'),
('desert', '{"verb": {"ipa_uk": "/dɪˈzɜːt/", "ipa_us": "/dɪˈzɝt/"}}'),
('contract', '{"verb": {"ipa_uk": "/kənˈtɹækt/", "ipa_us": "/kənˈtɹækt/"}}'),
('conduct', '{"noun": {"ipa_uk": "/ˈkɒndʌkt/", "ipa_us": "/ˈkɑndʌkt/"}}'),
('conflict', '{"verb": {"ipa_uk": "/kənˈflɪkt/", "ipa_us": "/kənˈflɪkt/"}}'),
('contest', '{"verb": {"ipa_uk": "/kənˈtɛst/", "ipa_us": null}}'),
('convert', '{"noun": {"ipa_uk": "/ˈkɒn.vət/", "ipa_us": "/ˈkɑn.vɚt/"}}'),
('convict', '{"noun": {"ipa_uk": "/ˈkɒnvɪkt/", "ipa_us": "/ˈkɑnvɪkt/"}}'),
('export', '{"verb": {"ipa_uk": "/ɪksˈpɔːt/", "ipa_us": "/ɪksˈpɔɹt/"}}'),
('import', '{"verb": {"ipa_uk": "/ɪmˈpɔːt/", "ipa_us": "/ɪmˈpɔɹt/"}}'),
('increase', '{"noun": {"ipa_uk": "/ˈɪnkɹiːs/", "ipa_us": "/ˈɪnkɹiːs/"}}'),
('insult', '{"noun": {"ipa_uk": "/ˈɪnsʌlt/", "ipa_us": "/ˈɪnsʌlt/"}}'),
('progress', '{"verb": {"ipa_uk": "/pɹəˈɡɹɛs/", "ipa_us": null}}'),
('rebel', '{"noun": {"ipa_uk": "/ˈɹɛb.əl/", "ipa_us": "/ˈɹɛb.əl/"}, "verb": {"ipa_uk": "/ɹɪˈbɛl/", "ipa_us": "/ɹɪˈbɛl/"}}'),
('subject', '{"verb": {"ipa_uk": "/səbˈd͡ʒɛkt/", "ipa_us": "/səbˈd͡ʒɛkt/"}}'),
('suspect', '{"noun": {"ipa_uk": "/ˈsʌspɛkt/", "ipa_us": null}, "adjective": {"ipa_uk": "/ˈsʌspɛkt/", "ipa_us": null}}'),
('transport', '{"verb": {"ipa_uk": "/tɹænsˈpɔːt/", "ipa_us": "/tɹænsˈpɔɹt/"}}'),
('upset', '{"noun": {"ipa_uk": "/ˈʌp.sɛt/", "ipa_us": null}}'),
('extract', '{"noun": {"ipa_uk": "/ˈɛkstɹækt/", "ipa_us": "/ˈɛkstɹækt/"}, "verb": {"ipa_uk": "/ɪkˈstɹækt/", "ipa_us": "/ɪkˈstɹækt/"}}'),
('perfect', '{"verb": {"ipa_uk": "/pəˈfɛkt/", "ipa_us": "/pɚˈfɛkt/"}}'),
('content', '{"adjective": {"ipa_uk": "/kənˈtɛnt/", "ipa_us": "/kənˈtɛnt/"}, "verb": {"ipa_uk": "/kənˈtɛnt/", "ipa_us": "/kənˈtɛnt/"}}'),
('use', '{"verb": {"ipa_uk": "/juːz/", "ipa_us": "/juz/"}}'),
('house', '{"verb": {"ipa_uk": "/haʊz/", "ipa_us": "/haʊz/"}}'),
('close', '{"adjective": {"ipa_uk": "/kləʊs/", "ipa_us": "/kloʊs/"}, "adverb": {"ipa_uk": "/kləʊs/", "ipa_us": "/kloʊs/"}}'),
('excuse', '{"noun": {"ipa_uk": "/ɪkˈskjuːs/", "ipa_us": "/ɪksˈkjus/"}, "verb": {"ipa_uk": "/ɪkˈskjuːz/", "ipa_us": "/ɪksˈkjuz/"}}'),
('abuse', '{"noun": {"ipa_uk": "/əˈbjuːs/", "ipa_us": "/əˈbjus/"}, "verb": {"ipa_uk": "/əˈbjuːz/", "ipa_us": "/əˈbjuz/"}}'),
('estimate', '{"noun": {"ipa_uk": "/ˈɛs.tɪ.mət/", "ipa_us": "/ˈɛs.tə.mət/"}, "verb": {"ipa_uk": "/ˈɛs.tɪˌmeɪt/", "ipa_us": "/ˈɛs.təˌmeɪt/"}}'),
('graduate', '{"noun": {"ipa_uk": "/ˈɡɹæd͡ʒuət/", "ipa_us": "/ˈɡɹæd͡ʒuɪt/"}, "verb": {"ipa_uk": "/ˈɡɹædjueɪt/", "ipa_us": "/ˈɡɹæd͡ʒueɪt/"}}'),
('delegate', '{"noun": {"ipa_uk": "/ˈdɛlɪɡət/", "ipa_us": "/ˈdɛlɪɡət/"}, "verb": {"ipa_uk": "/ˈdɛlɪˌɡeɪt/", "ipa_us": "/ˈdɛlɪˌɡeɪt/"}}'),
('associate', '{"noun": {"ipa_uk": "/əˈsəʊʃi.ət/", "ipa_us": "/əˈsoʊʃi.ət/"}, "adjective": {"ipa_uk": "/əˈsəʊʃi.ət/", "ipa_us": "/əˈsoʊʃi.ət/"}}'),
('advocate', '{"noun": {"ipa_uk": "/ˈæd.və.kət/", "ipa_us": "/ˈæd.və.kət/"}}'),
('duplicate', '{"noun": {"ipa_uk": "/ˈd(j)uː.plɪ.kət/", "ipa_us": "/ˈd(j)uː.plɪ.kət/"}, "adjective": {"ipa_uk": "/ˈd(j)uː.plɪ.kət/", "ipa_us": "/ˈd(j)uː.plɪ.kət/"}}'),
('moderate', '{"verb": {"ipa_uk": "/ˈmɒdəɹeɪt/", "ipa_us": "/ˈmɑdəɹeɪt/"}}'),
('approximate', '{"verb": {"ipa_uk": "/əˈpɹɒk.sɪ.meɪt/", "ipa_us": "/əˈpɹɑk.sə.meɪt/"}}'),
('appropriate', '{"verb": {"ipa_uk": "/əˈpɹəʊ.pɹi.eɪt/", "ipa_us": "/əˈpɹoʊ.pɹi.eɪt/"}}'),
('elaborate', '{"adjective": {"ipa_uk": "/ɪˈlæb.(ə.)ɹət/", "ipa_us": "/ɪˈlæb.(ə.)ɹət/"}}'),
('alternate', '{"verb": {"ipa_uk": "/ˈɒl.tə(ɹ)ˌneɪt/", "ipa_us": "/ˈɔl.tɚ.neɪt/"}}'),
('intimate', '{"verb": {"ipa_uk": "/ˈɪn.tɪ.meɪt/", "ipa_us": "/ˈɪn.tɪ.meɪt/"}}');
UPDATE dictionary_words w SET pos_pronunciations = p.data FROM pos_pron p WHERE w.headword = p.headword;
COMMIT;
